<?php

die('Here where all the magic should append');