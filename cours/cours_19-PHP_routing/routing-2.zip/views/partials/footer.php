    <footer>
        © HETIC P2022
    </footer>
    <script src="./assets/script.js"></script>
</body>
</html>