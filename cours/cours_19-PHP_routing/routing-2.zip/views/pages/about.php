<?php include '../views/partials/header.php' ?>

<h1>About</h1>

<?php include '../views/partials/footer.php' ?>