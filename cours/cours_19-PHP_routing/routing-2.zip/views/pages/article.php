<?php include '../views/partials/header.php' ?>

<h1>Article <?= $id ?></h1>

<?php include '../views/partials/footer.php' ?>