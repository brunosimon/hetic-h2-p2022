<?php

$title = 'My Website';

include '../views/pages/home.php';