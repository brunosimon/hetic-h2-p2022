<?php

$title = 'Not found';

include '../views/pages/404.php';