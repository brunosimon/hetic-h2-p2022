<?php

$title = 'About us';

include '../views/pages/about.php';